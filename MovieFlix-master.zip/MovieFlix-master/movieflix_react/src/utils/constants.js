export const API_KEY = "05e86f2a7e278be8d02ad053ececfcaf"
export const TMDB_BASE_URL="https://api.themoviedb.org/3"
export const LOCALHOST_PATH="http://localhost:8000/api/user/add" //TO POST DATA TO MONGODB VIA LOCALHOST