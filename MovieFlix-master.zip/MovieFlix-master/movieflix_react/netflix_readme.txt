Technologies used:

1.node.js ---- backend
2.Express   ----server
3.Mongodb
4.React      --- frontend
5.Redux        ---state management
6.React-router-dom   ---routing
7.Firebase           ----database
8.Styled-components
9.TMDB Api ----- movies/webseries data
10.React-icons
11.Axios --- for api fetching